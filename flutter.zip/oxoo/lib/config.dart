class Config {
  //set your api server url here
  static String apiServerUrl              = "http://tv.bebin.fun/rest-api/";
  //set your api key here
  static String apiKey                    = "5adec1b728f80b08ca0ff88f";
  //set your onesignalID here
  static String oneSignalID               = "xxxxx-xxxx-xxxx-xxxx-xxxxxxx";
  //set term and conditaions url here
  static String termsPolicyUrl            = "http://tv.bebin.fun/terms/";



  static final bool enableFacebookAuth    = true;
  static final bool enableGoogleAuth      = true;
  static final bool enablePhoneAuth       = true;
  static final bool enableAppleAuthForIOS = true;
  //publicKeyBase64 from play store to implement in app purchase
  static final String publicKeyBase64     ="xxxxxxx/xxx+xxx+xxx+xx+xxxx+xxx+xx+xxxxx+xxx/x56/W+xxx+xx+xx/xx";
}
